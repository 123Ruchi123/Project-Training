package spring.maven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenNameApplicationTests {

	@Test
	void contextLoads() {
	}

}
